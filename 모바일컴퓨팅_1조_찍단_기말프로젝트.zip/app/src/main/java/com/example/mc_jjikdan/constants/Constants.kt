package com.example.mc_jjikdan.constants

object Constants {
    const val apiURL = "http://3.34.42.130:8080/"
}