package com.example.mc_jjikdan

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class JjikdanApplication : Application() {
}