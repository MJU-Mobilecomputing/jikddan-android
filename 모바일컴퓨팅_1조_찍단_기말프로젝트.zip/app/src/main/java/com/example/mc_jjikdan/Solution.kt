package com.example.mc_jjikdan

data class Solution(
    val text: String
)
