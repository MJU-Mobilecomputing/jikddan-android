package com.example.mc_jjikdan.api.menu

class repository {
}